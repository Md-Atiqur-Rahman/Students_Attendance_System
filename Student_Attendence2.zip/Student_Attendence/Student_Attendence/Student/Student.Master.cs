﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Student
{
    public partial class Student : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {



                if (Page.IsPostBack == false)
                {

                    using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                    {

                        var st = db.StudentMst_SELECT_by_uname(Session["sname"].ToString());
                        var erm = st.ToList();
                        Image4.ImageUrl = erm.SingleOrDefault().Image;
                        Label1.Text = erm.SingleOrDefault().Name;
                    }

                }
            }
            catch (Exception ex)
            {

                this.Session["exceptionMessage"] = ex.Message;
                Response.Redirect("~/Home.aspx");
            }

        }
    }
}