﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Student
{
    public partial class MyProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

            
            if (Page.IsPostBack == false)
            {

                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {

                    var StuDT = db.StudentMst_SELECT_by_uname(Session["sname"].ToString());
                    var erm = StuDT.ToList();
                  

                    lblname.Text = erm.SingleOrDefault().Name;
                    lblroll.Text = erm.SingleOrDefault().RollNo;

                    txtemail.Text = erm.SingleOrDefault().Email;
                    txtmobile.Text = erm.SingleOrDefault().Mobile;
                    txtadd.Text = erm.SingleOrDefault().Add;
                    txtcity.Text = erm.SingleOrDefault().City;
                    txtpin.Text = erm.SingleOrDefault().Pincode;
                    Imgprofile.ImageUrl = erm.SingleOrDefault().Image;
                    ViewState["sid"] = erm.SingleOrDefault().SID;

                }
            }
            }
            catch (Exception ex)
            {

                this.Session["exceptionMessage"] = ex.Message;
                Response.Redirect("~/Home.aspx");
            }
        }

        protected void btnchange_Click(object sender, EventArgs e)
        {
            FileUpload1.SaveAs(Server.MapPath("~/Studentimg/" + FileUpload1.FileName));
            Imgprofile.ImageUrl = "~/Studentimg/" + FileUpload1.FileName.ToString();
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {

                db.StudentMst_UPDATE(Convert.ToInt32(ViewState["sid"].ToString()), txtemail.Text, txtmobile.Text, Imgprofile.ImageUrl.ToString(), txtadd.Text, txtcity.Text, txtpin.Text);
                lblupdate.Text = "Updated Successfully";
            }
        }
    }
}