﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Student
{
    public partial class Myattendance : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnreport_Click(object sender, EventArgs e)
        {
            if (drpmonth.SelectedIndex == 0)
            {
                lbl.Text = "Select month first !!";
            }
            else
            {

                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {

                    var StuDT = db.StudentMst_SELECT_by_uname(Session["sname"].ToString());
                    var erm = StuDT.ToList();
                    var AttDT = db.Attendancemst_SELECT_BY_ROLLNO_month(erm.SingleOrDefault().RollNo, "%" + drpmonth.SelectedValue + "%");

                    GridView1.DataSource = AttDT;
                    GridView1.DataBind();
                    lbl.Text = "Result = " + GridView1.Rows.Count.ToString();


                }

              
            }
        }
    }
}