﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Student
{
    public partial class Complain : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {

                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {

                  var  CompDT = db.Complainmst_SELECT();
                    GridView1.DataSource = CompDT;
                    GridView1.DataBind();
                }

                
            }
            lbl.Text = "";
        }

        protected void btnsend_Click(object sender, EventArgs e)
        {

            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {

                var StuDT = db.StudentMst_SELECT_by_uname(Session["sname"].ToString());
                var erm = StuDT.ToList();
                db.Complainmst_INSERT(erm.SingleOrDefault().RollNo, erm.SingleOrDefault().Name, txtsubj.Text, txtmsg.Text, "Pending");
               var CompDT = db.Complainmst_SELECT();
                GridView1.DataSource = CompDT;
                GridView1.DataBind();
                lbl.Text = "complain Sent";
                txtmsg.Text = "";
                txtsubj.Text = "";

               
            }
            
           
        }
    }
}