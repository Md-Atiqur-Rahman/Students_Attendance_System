﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Student
{
    public partial class Main : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                try
                {


                    using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                    {

                        var StuDT = db.StudentMst_SELECT_by_uname(Session["sname"].ToString());
                        var erm = StuDT.ToList();



                        //StuDT = StuAdapter.Select_UNAME(Session["sname"].ToString());


                        var AttDT = db.Attendancemst_SELECT_BY_ROLLNO(erm.SingleOrDefault().RollNo);
                        var Aerm = AttDT.ToList();
                        lbltotalatt.Text = Aerm.Count().ToString();


                        var APreseent = db.Attendancemst_SELECT_BY_ROLLNO_and_STATUS(erm.SingleOrDefault().RollNo, "Present");
                        var AP = APreseent.ToList();
                        lblpresent.Text = AP.Count.ToString();


                        var AAbsent = db.Attendancemst_SELECT_BY_ROLLNO_and_STATUS(erm.SingleOrDefault().RollNo, "Absent");
                        var Ab = AAbsent.ToList();
                        lblabsent.Text = Ab.Count.ToString();



                        var Aleave = db.Attendancemst_SELECT_BY_ROLLNO_and_STATUS(erm.SingleOrDefault().RollNo, "Leave");
                        var ALv = Aleave.ToList();
                        lblleave.Text = ALv.Count.ToString();



                        var LeaveDT = db.Leavemst_SELECT_rollno(erm.SingleOrDefault().RollNo);
                        var lv = LeaveDT.ToList();
                        lbltotalleave.Text = lv.Count.ToString();


                        var CompDT = db.Complainmst_SELECT_BY_ROLLNO(erm.SingleOrDefault().RollNo);
                        var cmpl = CompDT.ToList();
                        lbltotalattcompl.Text = cmpl.Count.ToString();

                    }
                }

                catch (Exception ex)
                {

                    this.Session["exceptionMessage"] = ex.Message;
                    Response.Redirect("~/Home.aspx");
                }
            }
        }
    }
}