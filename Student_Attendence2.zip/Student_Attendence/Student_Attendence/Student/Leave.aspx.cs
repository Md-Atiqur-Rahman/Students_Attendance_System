﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Student
{
    public partial class Leave : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lbl.Text = "";
        }

        protected void btnappluleave_Click(object sender, EventArgs e)
        {

            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {

                var StuDT = db.StudentMst_SELECT_by_uname(Session["sname"].ToString());
                var erm = StuDT.ToList();
                db.Leavemst_INSERT(erm.SingleOrDefault().RollNo, erm.SingleOrDefault().Name, erm.SingleOrDefault().StdName, txtmsg.Text, Convert.ToInt32(DropDownList1.SelectedItem.Text), "Pending");
                lbl.Text = "Apply for leave successfully";
                txtmsg.Text = "";
                DropDownList1.SelectedIndex = 0;
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
        }

        protected void Button8_Click(object sender, EventArgs e)
        {

            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                MultiView1.ActiveViewIndex = 1;
                var StuDT = db.StudentMst_SELECT_by_uname(Session["sname"].ToString());
                var erm = StuDT.ToList();
                var LeaveDT = db.Leavemst_SELECT_rollno(erm.SingleOrDefault().RollNo);

                GridView1.DataSource = LeaveDT;
                GridView1.DataBind();
            }
           
        }
    }
}