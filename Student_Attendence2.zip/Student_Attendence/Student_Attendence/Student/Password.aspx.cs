﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Student
{
    public partial class Password : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnchangepass_Click(object sender, EventArgs e)
        {

            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {

              var  StuDT = db.StudentMST_SELECT_check_current_pass(txtcurrent.Text, Session["sname"].ToString());
                var erm = StuDT.ToList();
                if (erm.Count == 1)
                {

                    db.StudentMST_SELECT_ChangePass(txtnewpass.Text, Session["sname"].ToString());
                    lbl.Text = "Password Changed";

                }
                else
                {

                    lbl.Text = "Invalid Current Password";
                }


            }

           
           
        }
    }
}