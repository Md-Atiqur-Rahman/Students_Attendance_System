﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Admin
{
    public partial class AddStd : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnaddstd_Click(object sender, EventArgs e)
        {
            StdMst std = new StdMst()
            {
                StdName = txtstdname.Text
            };
            using(StudentAttendence1Entities db =new StudentAttendence1Entities())
            {
                db.StdMsts.Add(std);
                db.SaveChanges();
                lbl.Text = "Standered Added Successfully.";
              
                txtstdname.Text = "";
                GridView1.DataBind();
            }
        }

        protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            lbl.Text = "Record Updated Successfully";
        }

        protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            lbl.Text = "Recoed Deleted Successfully.";
        }

       
    }
}