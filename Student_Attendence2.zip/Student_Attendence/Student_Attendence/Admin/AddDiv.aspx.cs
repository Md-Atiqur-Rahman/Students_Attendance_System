﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Admin
{
    public partial class AddDiv : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            DivMst div = new DivMst()
            {
                StdName=drpstd.SelectedItem.Value,
                DivName=txtdname.Text,
                Seat=int.Parse(txtseat.Text)
            };
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                db.DivMsts.Add(div);
                db.SaveChanges();
                lbl.Text = "Record Added Successfully";

                txtdname.Text = "";
                txtseat.Text = "";
                GridView1.DataBind();
            }
        }

        protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
        {
            lbl.Text = "Record Updated Successfully";
        }

        protected void GridView1_RowDeleted(object sender, GridViewDeletedEventArgs e)
        {
            lbl.Text = "Record Deleted Successfully";
        }
    }
}