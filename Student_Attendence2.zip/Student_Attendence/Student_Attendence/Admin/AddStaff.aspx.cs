﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Admin
{
    public partial class AddStaff : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            drpstd.Items.Insert(0, "SELECT");
        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
          
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                //StaffDT = StaffAdapter.Select_UNAME(txtuname.Text);
            var  st = db.StaffMST_SELECT_by_uname(txtuname.Text);

                if (st.Select(s=>s.Uname).SingleOrDefault()==txtuname.Text)
                {
                    lbl.Text = "UserName alredy exists !!";


                    txtadd.Text = "";
                    txtcity.Text = "";
                    txtemail.Text = "";
                    txtmobile.Text = "";
                    txtname.Text = "";
                    txtpin.Text = "";
                    txtqual.Text = "";
                    //txtuname.Text = "";
                    drpstd.SelectedIndex = 0;
                }
                else
                { 




                FileUpload1.SaveAs(Server.MapPath("~/StaffImg/" + FileUpload1.FileName));
                //StaffAdapter.Insert(txtname.Text, drpstd.SelectedItem.Text, txtemail.Text, txtmobile.Text, FileUpload1.FileName, txtqual.Text, txtadd.Text, txtcity.Text, txtpin.Text, txtuname.Text, txtpass.Text, DropDownList1.SelectedItem.Text);
                db.staffmst_INSERT(txtname.Text, drpstd.SelectedItem.Text, txtemail.Text, txtmobile.Text, "~/StaffImg/" + FileUpload1.FileName, txtqual.Text, txtadd.Text, txtcity.Text, txtpin.Text, txtuname.Text, txtpass.Text, DropDownList1.SelectedItem.Text);
                lbl.Text = "Record Added Successfully";

                txtadd.Text = "";
                txtcity.Text = "";
                txtemail.Text = "";
                txtmobile.Text = "";
                txtname.Text = "";
                txtpin.Text = "";
                txtqual.Text = "";
                txtuname.Text = "";
                drpstd.SelectedIndex = 0;
            }
            }
        }
    }
}