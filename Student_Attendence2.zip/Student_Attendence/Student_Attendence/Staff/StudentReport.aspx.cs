﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Staff
{
    public partial class StudentReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

           
            lbl.Text = "";
            if (Page.IsPostBack == false)
            {

                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {
                    try
                    {

                   
                    var st = db.StaffMST_SELECT_by_uname(Session["uname"].ToString());
                    var erm = st.ToList();

                  var   StdDT = db.STDMST_SELECT();

                  drpstd.DataSource = StdDT;
                  drpstd.DataTextField = "STDName";
                  drpstd.DataValueField = "SID";
                  drpstd.DataBind();
                  drpstd.Items.Insert(0, "SELECT");


                  var div = db.DIVMST_SELECT();
                  drpdiv.DataSource = div;
                    drpdiv.DataTextField = "DivName";
                    drpdiv.DataValueField = "DID";
                    drpdiv.DataBind();
                    drpdiv.Items.Insert(0, "SELECT");
                    }
                    catch (Exception ex)
                    {

                        this.Session["exceptionMessage"] = ex.Message;
                        Response.Redirect("~/Home.aspx");
                    }


                }

               

            }
            }
            catch (Exception ex)
            {

                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('" + ex.Message + "');", true);
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                var StuDT = db.StudentMst_SELECT_STD_DIV(drpstd.SelectedItem.Text, drpdiv.SelectedItem.Text);
                GridView1.DataSource = StuDT;
                GridView1.DataBind();
                lbl.Text = "Total Student = " + GridView1.Rows.Count.ToString();
            }
        }
    }
}