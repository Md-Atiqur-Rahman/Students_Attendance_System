﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Staff
{
    public partial class Att : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            lblatt.Text = "";
            lblcnt.Text = "";
            try
            {

            
            if (Page.IsPostBack == false)
            {
                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {
                    try
                    {

                    
                    var st = db.StaffMST_SELECT_by_uname(Session["uname"].ToString());
                    var erm = st.ToList();

                   
                    //StdDT = StdAdapter.SelectStd();
                    //drpstd.DataSource = StdDT;
                    //drpstd.DataTextField = "STDName";
                    //drpstd.DataValueField = "SID";
                    //drpstd.DataBind();           
                    //  drpstd.Items.Insert(0, "SELECT");
                    lblstd.Text = erm.SingleOrDefault().StdName;

                    var DivDT = db.DIVMST_SELECT_BY_STD(erm.SingleOrDefault().StdName);
                    drpdiv.DataSource = DivDT;
                    drpdiv.DataTextField = "DivName";
                    drpdiv.DataValueField = "DID";
                    drpdiv.DataBind();
                    drpdiv.Items.Insert(0, "SELECT");

                    }
                    catch (Exception ex)
                    {

                        this.Session["exceptionMessage"] = ex.Message;
                        Response.Redirect("~/Home.aspx");
                    }
                }
            }
            }
            catch (Exception ex)
            {

                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('" + ex.Message + "');", true);
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                var StuDT = db.StudentMst_SELECT_STD_DIV(lblstd.Text, drpdiv.SelectedItem.Text);
               
               
                GridView1.DataSource = StuDT;
                GridView1.DataBind();
                MultiView1.ActiveViewIndex = 0;
            }
        }

        protected void btnaddatt_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
               var AttDT = db.Attendancemst_SELECT_Allready_Saved(GridView1.Rows[0].Cells[0].Text, Calendar1.SelectedDate.Date.GetDateTimeFormats()[8].ToString());
                 var erm1 = AttDT.ToList();
                
                if (erm1.Count== 1)
                {
                    lblatt.Text = "Attendance Alredy Saved";
                }
                else
                {

                    for (int i = 0; i < GridView1.Rows.Count; i++)
                    {
                        string rollno = GridView1.Rows[i].Cells[0].Text;
                        string name = GridView1.Rows[i].Cells[1].Text;
                        DropDownList drpattt = GridView1.Rows[i].Cells[2].FindControl("drpatt") as DropDownList;

                        db.Attendancemst_INSERT(rollno, name, Calendar1.SelectedDate.Date.GetDateTimeFormats()[8].ToString(), drpattt.SelectedItem.Text, Session["uname"].ToString());

                    }
                    MultiView1.ActiveViewIndex = -1;
                    drpdiv.SelectedIndex = 0;
                    lblatt.Text = "Attendance Saved";
                }
            }
        }
    }
}