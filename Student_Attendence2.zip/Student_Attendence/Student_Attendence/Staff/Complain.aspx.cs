﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Staff
{
    public partial class Complain : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
            if (Page.IsPostBack == false)
            {

                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {

                    string rno = Session["std"].ToString().Substring(0, 1);
                  var  CompDT = db.Complainmst_SELECT_FOr_Teacher(rno + "%");
                    GridView1.DataSource = CompDT;
                    GridView1.DataBind();

                    lblcomplain.Text = GridView1.Rows.Count.ToString();
                }
               
            }
        }

        protected void btnreplyy_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {

                db.Complainmst_UPDATE_Reply(Convert.ToInt32(ViewState["cid"].ToString()), txtans.Text);
                txtans.Text = "";

                string rno = Session["std"].ToString().Substring(0, 1);

               var CompDT = db.Complainmst_SELECT_FOr_Teacher(rno + "%");
                GridView1.DataSource = CompDT;
                GridView1.DataBind();
                MultiView1.ActiveViewIndex = 0;
                lblcomplain.Text = GridView1.Rows.Count.ToString();
            }

           
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {

                MultiView1.ActiveViewIndex = 1;
               var CompDT = db.Complainmst_SELECT_BYID(Convert.ToInt32(e.CommandArgument.ToString()));
               var erm = CompDT.ToList();
               lblrno.Text = erm.SingleOrDefault().Rollno;

               lblname.Text = erm.SingleOrDefault().Name;
               lblcomp.Text = erm.SingleOrDefault().Message;
                lblsub.Text = erm.SingleOrDefault().Subject;
                ViewState["cid"] = erm.SingleOrDefault().CID;
            }
            
          
        }

        protected void Cancel_Click(object sender, EventArgs e)
        {
            MultiView1.ActiveViewIndex = 0;
        }
    }
}