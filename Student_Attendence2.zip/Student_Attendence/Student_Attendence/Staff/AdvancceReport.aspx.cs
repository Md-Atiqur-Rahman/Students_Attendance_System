﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Staff
{
    public partial class AdvancceReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {


                
                if (Page.IsPostBack == false)
                {
                    

                   

                    using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                    {
                        try
                        {


                            var st = db.StaffMST_SELECT_by_uname(Session["uname"].ToString());
                            var erm = st.ToList();



                            lblstd.Text = erm.SingleOrDefault().StdName;

                            var DivDT = db.DIVMST_SELECT_BY_STD(erm.SingleOrDefault().StdName);
                            drpdiv.DataSource = DivDT;
                            drpdiv.DataTextField = "DivName";
                            drpdiv.DataValueField = "DID";
                            drpdiv.DataBind();
                            drpdiv.Items.Insert(0, "SELECT");
                            drpstudent.Items.Insert(0, "SELECT");
                        }
                        catch (Exception ex)
                        {

                            this.Session["exceptionMessage"] = ex.Message;
                            Response.Redirect("~/Home.aspx");
                        }
                      


                    }



                }
            }
            catch (Exception ex)
            {

                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('" + ex.Message + "');", true);
            }
        }

        protected void drpdiv_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {

                var StuDT = db.StudentMst_SELECT_STD_DIV(lblstd.Text, drpdiv.SelectedItem.Text);

                drpstudent.DataSource = StuDT;
                drpstudent.DataTextField = "rollno";
                drpstudent.DataValueField = "sid";
                drpstudent.DataBind();
                drpstudent.Items.Insert(0, "SELECT");
            }
        }

        protected void btnsarch_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
               var StuDT = db.StudentMst_SELECT_BYID(Convert.ToInt32(drpstudent.SelectedValue));
               var erm1 = StuDT.ToList();
                if (erm1.Count == 1)
                {
                    lblroll.Text = erm1.SingleOrDefault().RollNo;
                    lblname.Text = erm1.SingleOrDefault().Name;
                    lblemail.Text = erm1.SingleOrDefault().Email;
                    lblmobile.Text = erm1.SingleOrDefault().Mobile;
                    lbldob.Text = erm1.SingleOrDefault().DOB;
                    lbladd.Text = erm1.SingleOrDefault().Add;
                    lblcity.Text = erm1.SingleOrDefault().City;
                    lblpin.Text = erm1.SingleOrDefault().Pincode;
                    lbluname.Text = erm1.SingleOrDefault().Uname;
                    lblpass.Text = erm1.SingleOrDefault().Pass;
                    imgg.ImageUrl = erm1.SingleOrDefault().Image;
                    MultiView1.ActiveViewIndex = 0;
                }
                else
                {
                    MultiView1.ActiveViewIndex = -1;
                }
            }
        }
    }
}