﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Staff
{
    public partial class AddStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

           
            if (Page.IsPostBack == false)
            {
                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {

                    var st = db.StaffMST_SELECT_by_uname(Session["uname"].ToString());
                    var erm = st.ToList();
                    lblstd.Text = erm.SingleOrDefault().StdName;
                    var DivDT = db.DIVMST_SELECT_BY_STD(erm.SingleOrDefault().StdName);
                    drpdiv.DataSource = DivDT;
                    drpdiv.DataTextField = "DivName";
                    drpdiv.DataValueField = "DID";
                    drpdiv.DataBind();
                    drpdiv.Items.Insert(0, "SELECT");

                   
                }


            }

            }
            catch (Exception ex)
            {

                this.Session["exceptionMessage"] = ex.Message;
                Response.Redirect("~/Home.aspx");
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            try
            {

            
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                //Total Seat 
                var st = db.DIVMST_SELECT_BYID(Convert.ToInt32(drpdiv.SelectedValue));
                var erm = st.ToList();     
                lblcnt.Text = "Total Seat = " + erm.SingleOrDefault().Seat;
                MultiView1.ActiveViewIndex = 0;

                //Total Admitted
               var StuDT = db.StudentMst_SELECT_STD_DIV(lblstd.Text, drpdiv.SelectedItem.Text);
               var erm1 = StuDT.ToList();
               int rstu = Convert.ToInt32(erm.SingleOrDefault().Seat) - Convert.ToInt32(erm1.Count.ToString());
               lblstudent.Text = "Total Admitted =" + erm1.Count.ToString() + " , Remaining Student = " + rstu;

                string stddd = lblstd.Text.Substring(0, 1);
                int rno = Convert.ToInt32(erm1.Count.ToString()) + 1;
                if (rno.ToString().Length < 2)
                {
                    string newrno = "0" + rno.ToString();
                    txtroll.Text = stddd + drpdiv.SelectedItem.Text + newrno;
                }
                else
                {
                    txtroll.Text = stddd + drpdiv.SelectedItem.Text + rno;
                }

            }
            }
            catch (Exception ex)
            {

                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('" + ex.Message + "');", true);
            }
            
            
            
        }

        protected void btnstuadd_Click(object sender, EventArgs e)
        {
            if (FileUpload1.HasFile)
            {
                FileUpload1.SaveAs(Server.MapPath("~/Studentimg/" + FileUpload1.FileName));
                DateTime bdate = Convert.ToDateTime(drpdd.SelectedItem.Text + " " + drpmm.SelectedItem.Text + " " + drpyyyy.SelectedItem.Text);

                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {

                    db.StudentMst_INSERT(txtroll.Text, txtname.Text, lblstd.Text, drpdiv.SelectedItem.Text, txtemail.Text, txtmobi.Text, bdate.GetDateTimeFormats()[8].ToString(), "~/Studentimg/" + FileUpload1.FileName, txtadd.Text, txtcity.Text, txtpin.Text, txtuname.Text, txtpass.Text);
                    lblmsg.Text = "Student Added.";
                    txtname.Text = "";
                    txtadd.Text = "";
                    txtcity.Text = "";
                    txtemail.Text = "";
                    txtmobi.Text = ""; txtpass.Text = "";
                    txtpin.Text = "";
                    txtuname.Text = "";
                    txtcpass.Text = "";
                    drpdd.SelectedIndex = 0;
                    drpmm.SelectedIndex = 0;
                    drpyyyy.SelectedIndex = 0;


                 var   DivDT = db.DIVMST_SELECT_BYID(Convert.ToInt32(drpdiv.SelectedValue));
                 var erm = DivDT.ToList();
                 lblcnt.Text = "Total Seat = " + erm.SingleOrDefault().Seat;
                    MultiView1.ActiveViewIndex = 0;


                    var StuDT = db.StudentMst_SELECT_STD_DIV(lblstd.Text, drpdiv.SelectedItem.Text);
                    var erm1 = StuDT.ToList();
                    int rstu = Convert.ToInt32(erm.SingleOrDefault().Seat) - Convert.ToInt32(erm1.Count.ToString());
                    lblstudent.Text = "Total Admitted =" + erm1.Count.ToString() + " , Remaining Student = " + rstu;

                    string stddd = lblstd.Text.Substring(0, 1);
                    int rno = Convert.ToInt32(erm1.Count.ToString()) + 1;
                    if (rno.ToString().Length < 2)
                    {
                        string newrno = "0" + rno.ToString();
                        txtroll.Text = stddd + drpdiv.SelectedItem.Text + newrno;
                    }
                    else
                    {
                        txtroll.Text = stddd + drpdiv.SelectedItem.Text + rno;
                    }

                   
                }
            }
        }
    }
}