﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Staff
{
    public partial class Staff : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Page.IsPostBack == false)
            {
                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {
                   
                    var st = db.StaffMST_SELECT_by_uname(Session["uname"].ToString());
                    var erm = st.ToList();
                    Image4.ImageUrl = erm.SingleOrDefault().Image;
                    Label1.Text = "Welcome " + erm.SingleOrDefault().Name;
                    Session["std"] = erm.SingleOrDefault().StdName;
                    //Image4.ImageUrl = st.ToList().SingleOrDefault().Image;
                    //Image4.ImageUrl = st.Select(s => s.Image).ToString();
                    //Label1.Text = "Welcome " + st.ToList().SingleOrDefault().Name;
                    //Session["std"] = st.ToList().SingleOrDefault().StdName;
                    //Label1.Text = "Welcome " + st.Select(s => s.Name).ToString();
                }
               
                

            }
        }
    }
}