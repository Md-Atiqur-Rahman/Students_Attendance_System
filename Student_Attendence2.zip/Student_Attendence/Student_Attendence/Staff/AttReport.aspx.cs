﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Staff
{
    public partial class AttReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

            
            if (Page.IsPostBack == false)
            {
                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {
                    try
                    {

                   
                    var st = db.StaffMST_SELECT_by_uname(Session["uname"].ToString());
                    var erm = st.ToList();


                    //StdDT = StdAdapter.SelectStd();
                    //drpstd.DataSource = StdDT;
                    //drpstd.DataTextField = "STDName";
                    //drpstd.DataValueField = "SID";
                    //drpstd.DataBind();           
                    //  drpstd.Items.Insert(0, "SELECT");
                    lblstd.Text = erm.SingleOrDefault().StdName;

                    var DivDT = db.DIVMST_SELECT_BY_STD(erm.SingleOrDefault().StdName);
                    drpdiv.DataSource = DivDT;
                    drpdiv.DataTextField = "DivName";
                    drpdiv.DataValueField = "DID";
                    drpdiv.DataBind();
                    drpdiv.Items.Insert(0, "SELECT");

                    }

                    catch (Exception ex)
                    {

                        this.Session["exceptionMessage"] = ex.Message;
                        Response.Redirect("~/Home.aspx");
                    }
                }

                
            }
            }
            catch (Exception ex)
            {

                this.Page.ClientScript.RegisterStartupScript(this.GetType(), "ex", "alert('" + ex.Message + "');", true);
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                string stddd = lblstd.Text.Substring(0, 1) + drpdiv.SelectedItem.Text;

                var AttDT = db.Attendancemst_SELECT_Report(stddd + "%", Calendar1.SelectedDate.Date.GetDateTimeFormats()[8].ToString());

                GridView1.DataSource = AttDT;
                GridView1.DataBind();
                lblcnt.Text = "Result = " + GridView1.Rows.Count.ToString();
            }
        }
    }
}