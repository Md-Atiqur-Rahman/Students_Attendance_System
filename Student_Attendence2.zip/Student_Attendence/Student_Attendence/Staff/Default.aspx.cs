﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence.Staff
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

          
            if (Page.IsPostBack == false)
            {
                using (StudentAttendence1Entities db = new StudentAttendence1Entities())
                {

                    var st = db.StaffMST_SELECT_by_uname(Session["uname"].ToString());
                    var erm = st.ToList();
                    lblname.Text = erm.SingleOrDefault().Name;
                    lblstd.Text = erm.SingleOrDefault().StdName;


                    txtemail.Text = erm.SingleOrDefault().Email;
                    txtmobile.Text = erm.SingleOrDefault().Mobile;
                    txtadd.Text = erm.SingleOrDefault().Add;
                    txtcity.Text = erm.SingleOrDefault().City;
                    txtpin.Text = erm.SingleOrDefault().Pincode;
                    Imgprofile.ImageUrl = erm.SingleOrDefault().Image;
                    ViewState["sid"] = erm.SingleOrDefault().SID;
                }
                
                
                
             

            }
            }
            catch (Exception ex)
            {

                this.Session["exceptionMessage"] = ex.Message;
                Response.Redirect("~/Home.aspx");
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                db.StaffMst_UPDATE(Convert.ToInt32(ViewState["sid"].ToString()), txtemail.Text, txtmobile.Text, Imgprofile.ImageUrl.ToString(), txtadd.Text, txtcity.Text, txtpin.Text);

            }
            
        }

        protected void btnchange_Click(object sender, EventArgs e)
        {
            FileUpload1.SaveAs(Server.MapPath("~/StaffImg/" + FileUpload1.FileName));
            Imgprofile.ImageUrl = "~/StaffImg/" + FileUpload1.FileName.ToString();
        }
    }
}