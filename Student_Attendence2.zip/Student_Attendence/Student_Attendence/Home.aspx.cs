﻿using Student_Attendence.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Student_Attendence
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnstafflogin_Click(object sender, EventArgs e)
        {
             using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
                var st = db.StaffMST_SELECT_login(txtstaffuname.Text, txtstaffpass.Text);

                if (st.Select(s => s.Uname == txtstaffuname.Text && s.Pass == txtstaffpass.Text).SingleOrDefault())
             {
                 Session["uname"] = txtstaffuname.Text;
                 Response.Redirect("Staff/Default.aspx");
             }
             else
             {
                 lblstafferror.Text = "Login Error !!";
             }
                
             }
          

                

        }

        protected void btnstudenlogin_Click(object sender, EventArgs e)
        {
            using (StudentAttendence1Entities db = new StudentAttendence1Entities())
            {
               var  StuDT = db.StudentMst_SELECT_login(txtstuuname.Text, txtstupass.Text);
               var st = StuDT.ToList();
                if (st.Count == 1)
                {
                    Session["sname"] = txtstuuname.Text;
                    Response.Redirect("Student/Main.aspx");
                }
                else
                {

                    lblstuerror.Text = "Login Error !!";
                }
            }
        }
    }
}